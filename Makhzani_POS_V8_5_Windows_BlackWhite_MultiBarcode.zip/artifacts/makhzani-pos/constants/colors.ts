/** Strict monochrome palette: white surfaces, black text and controls. */
const monochrome = {
  text: '#111111',
  tint: '#111111',
  background: '#FFFFFF',
  foreground: '#111111',
  card: '#FFFFFF',
  cardForeground: '#111111',
  primary: '#111111',
  primaryForeground: '#FFFFFF',
  secondary: '#F2F2F2',
  secondaryForeground: '#111111',
  muted: '#F5F5F5',
  mutedForeground: '#555555',
  accent: '#E5E5E5',
  accentForeground: '#111111',
  destructive: '#333333',
  destructiveForeground: '#FFFFFF',
  border: '#D6D6D6',
  input: '#CFCFCF',
};
const colors = { light: monochrome, dark: monochrome, radius: 12 };
export default colors;
