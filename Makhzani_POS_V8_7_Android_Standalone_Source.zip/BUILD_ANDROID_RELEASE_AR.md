# بناء APK مستقل لـ Makhzani POS V8.7

هذا الملف يضيف سير عمل GitHub Actions جديدًا باسم:
`.github/workflows/build-android-release.yml`

## المطلوب في مستودع GitHub

1. ارفع ملف `Makhzani_POS_V8_7_Android_Standalone_Source.zip` إلى جذر المستودع، بجانب مجلد `.github`.
2. أضف الملف `build-android-release.yml` داخل `.github/workflows/`.
3. افتح تبويب Actions واختر **Makhzani POS V8.7 - Android Release (Embedded JS)** ثم **Run workflow**.
4. عند النجاح نزّل Artifact باسم **Makhzani-POS-V8.7-Standalone-APK**.

## ما الذي يتحقق منه هذا البناء؟

- يفك ضغط أرشيف المصدر ويتحقق من ملفات workspace وملفات المشروع.
- يثبت التبعيات باستخدام lockfile.
- ينشئ مشروع Android بواسطة Expo دون تثبيت تفاعلي.
- ينشئ حزمة JavaScript الإنتاجية صراحةً ويضعها في `android/app/src/main/assets/index.android.bundle`.
- يبني Release APK ثم يفحص أن الحزمة موجودة داخل APK قبل رفعه.

إذا كان ملف المصدر ZIP مختلفًا في جذر المستودع، غيّر قيمة `ZIP` في خطوة **Verify V8.7 source archive** إلى اسمه الحقيقي.

ملاحظة: نجاح فحص تضمين JavaScript لا يثبت وحده سلامة كل وظائف التطبيق؛ يجب اختبار فتح التطبيق والعمل دون اتصال بخادم Metro بعد تثبيته.
